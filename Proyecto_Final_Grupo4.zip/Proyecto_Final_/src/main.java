import javax.swing.*;

public class main {
    public static void main(String[] args){
        boolean VolverMenu = true;  // inicializamos el menu para que entre en true
        while (VolverMenu == true) { // inicializamos el ciclo del menu
            int menu = Integer.parseInt(JOptionPane.showInputDialog(null, "<<<MENÚ PRINCIPAL>>> \n 1= Tienda Virtual \n 2 = Inventario \n 3 = Ventas \n 4 = Reportes \n 5 = Contacto \n 6 = SALIR \n"));

            if(1 <= menu && menu <= 6){
                if (menu == 1) {
                    // Arreglo de lo objetos Tienda Virtual
                    int cantPruc = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite la cantidad de productos"));
                    TiendaVirtual tienV[] = new TiendaVirtual[cantPruc];
                    for (int i = 0; i < cantPruc; i++) {
                        tienV[i] = new TiendaVirtual("", "", 0.0);
                        tienV[i].setProduc(JOptionPane.showInputDialog(null, "Escriba el producto:"));
                        tienV[i].setDesc(JOptionPane.showInputDialog(null, "Cuenta con descuento: \n Si \n No \n"));
                        tienV[i].setTipoDesc(Double.parseDouble(JOptionPane.showInputDialog(null, "Con cuanto descuento cuenta la prenda:")));
                        System.out.println("Producto:" + " " + tienV[i].getProduc() + " " + "Cuenta con descuento:" + " " + tienV[i].getDesc() + " " + "El descuento es de:" + " " + tienV[i].getTipoDesc() + " " + "Colones");
                    }
                    VolverMenu = true;
                }
                if (menu == 2) {
                    // Arreglo de lo objetos Invetario
                    int cantInve = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite la cantidad de productos"));
                    inventario inve[] = new inventario[cantInve];
                    for (int i = 0; i < cantInve; i++) {
                        inve[i] = new inventario("", 0, 0.0, 0);
                        inve[i].setTipoArticulo(JOptionPane.showInputDialog(null, "Digite el tipo de articulo:"));
                        inve[i].setCodigo(Integer.parseInt(JOptionPane.showInputDialog(null, "Digite el codigo del articulo:")));
                        inve[i].setPrecio(Double.parseDouble(JOptionPane.showInputDialog(null, "Digite el precio del articulo:")));
                        inve[i].setCantidad(Integer.parseInt(JOptionPane.showInputDialog(null, "Digite la cantidad de articulos:")));
                        System.out.println("Tipo de Articulo:" + " " + inve[i].getTipoArticulo() + " " + "Codigo del Articulo:" + " " + inve[i].getCodigo() + " " + "Precio del Articulo:" + " " + inve[i].getPrecio() + " " + "Cantidad de Articulos:" + " " + inve[i].getCantidad() + " " + "Colones");
                    }
                    VolverMenu = true;
                }
                if (menu == 3) {
                    // Arreglo de lo objetos ventas
                    ventas ventas1 [] = new ventas[1];
                    for (int i = 0; i < ventas1.length ; i++){
                        ventas1[i] = new ventas("","", 0, 0.0);
                        ventas1[i].setDia(JOptionPane.showInputDialog(null, "Digite el dia de la semana: \n Lunes \n Martes \n Miercoles \n Jueves \n Viernes"));
                        ventas1[i].setLocal(JOptionPane.showInputDialog(null, "Local donde se va hacer el cierre de caja: "));
                        ventas1[i].setVentasdiarias(Integer.parseInt(JOptionPane.showInputDialog(null, "Ventas que se realizaron el dia de hoy: ")));
                        ventas1[i].setCierreCaja(Double.parseDouble(JOptionPane.showInputDialog(null, "Cantidad de ganancias del dia de hoy: ")));
                        System.out.println("Dia de la semana: " + " " + ventas1[i].getDia() + " " + "Local: " + " " + ventas1[i].getLocal() + " " + "Ventas realizadas el dia de hoy: " + " " + ventas1[i].getVentasdiarias() + " " + "Cantidad de ganancias del dia de hoy: " + " " + ventas1[i].getCierreCaja() + " " + "Colones");
                    }
                    VolverMenu = true;
                }
                if (menu == 4) {
                    // Arreglo de lo objetos reportes
                    int catnreport = Integer.parseInt(JOptionPane.showInputDialog(null, "Cuantas facturas desea realizar?"));
                    resportes report[] = new resportes[catnreport];
                    for (int i = 0; i < catnreport; i++) {
                        report[i] = new resportes("", "", "", 0, 0.0);
                        report[i].setNomCliente(JOptionPane.showInputDialog(null, "Nombre del cliente:"));
                        report[i].setTienda(JOptionPane.showInputDialog(null, "Tienda donde se adquirio el producto:"));
                        report[i].setProducto(JOptionPane.showInputDialog(null, "Producto adquirido:"));
                        report[i].setCantProduc(Integer.parseInt(JOptionPane.showInputDialog(null, "Cantidad de productos:")));
                        report[i].setPreciofact(Double.parseDouble(JOptionPane.showInputDialog(null, "Precio del producto:")));
                        double precio_total = report[i].getCantProduc() * report[i].getPreciofact();
                        System.out.println("                 <<<FACTURA>>>                      ");
                        System.out.println("Nombre del Cliente:" + " " + report[i].getNomCliente());
                        System.out.println("Tienda:" + " " + report[i].getTienda());
                        System.out.println("Producto:" + " " + report[i].getProducto());
                        System.out.println("Cantidad de Productos:" + " " + report[i].getCantProduc());
                        System.out.println("Precio por Unidad:" + " " + report[i].getPreciofact() + " " + "Colones");
                        System.out.println("Precio Total a pagar es:" + " " + precio_total + " " + "Colones");
                    }
                    VolverMenu = true;
                }
                if (menu == 5){
                    // Arreglo de lo objetos Contacto
                    Contacto contacto [] = new Contacto[1];
                    for (int i = 0; i < contacto.length ; i++){
                        contacto[i] = new Contacto("",0,"");
                        contacto[i].setNombre("Empresa ServiTEC");
                        contacto[i].setNumero(89124355);
                        contacto[i].setCorreo("EmpresaServiTEC.Contacto@gmail.com");
                        System.out.println("Nuestro nombre es:" + " " + contacto[i].getNombre());
                        System.out.println("Nuestro numero es:" + " " + contacto[i].getNumero());
                        System.out.println("Tambien nos puede contactar por el correo:" + " " + contacto[i].getCorreo());
                    }
                }
                // Para cerrar el ciclo
                if (menu == 6) {
                    VolverMenu = false;
                }
                // Para Validar que la opcion sea valida
            }else{
                JOptionPane.showMessageDialog(null, "Ingrese una opcion valida");
                VolverMenu = true;
            }



        }

    }
}
