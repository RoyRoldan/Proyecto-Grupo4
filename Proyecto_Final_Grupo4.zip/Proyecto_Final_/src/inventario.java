/**
 * Clase inventario
 * <p>Objeto Base usado para crear la Tienda Virtual</p>
 * @author J.Barahona,E.Jimenez,J.Sanchez,R.Roldan
 *
 */
public class inventario {

    /**
     * Atributo para almacenar el tipoArticulo
     */
    private String tipoArticulo;

    /**
     * Atributo para almacenar el codigo
     */
    private int codigo;

    /**
     * Atributo para almacenar el precio
     */
    private Double precio;

    /**
     * Atributo para almacenar el cantidad
     */
    private int cantidad;

    /**
     * Constructor de la clase inventario, el cual recibe los valores por defecto
     */
    public inventario(String tipoArticulo, int codigo, Double precio, int cantidad){
        this.tipoArticulo = tipoArticulo;
        this.codigo = codigo;
        this.precio = precio;
        this.cantidad = cantidad;
    }

    public String getTipoArticulo() {
        return tipoArticulo;
    }

    public void setTipoArticulo(String tipoArticulo) {
        this.tipoArticulo = tipoArticulo;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
}
