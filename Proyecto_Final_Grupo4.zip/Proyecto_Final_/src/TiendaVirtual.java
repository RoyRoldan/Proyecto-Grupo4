/**
 * Clase Tienda Virtual
 * <p>Objeto Base usado para crear la Tienda Virtual</p>
 * @author J.Barahona,E.Jimenez,J.Sanchez,R.Roldan
 *
 */
public class TiendaVirtual {

    /**
     * Atributo para almacenar el Producto
     */
    private String produc;

    /**
     * Atributo para almacenar el Descuento
     */
    private String desc;

    /**
     * Atributo para almacenar el Tipo de Descuento
     */
    private Double tipoDesc;

    /**
     * Constructor de la clase Tienda Virtual, el cual recibe los valores por defecto
     */
    public TiendaVirtual(String produc, String desc , Double tipoDesc ) {
        this.produc = produc;
        this.desc = desc;
        this.tipoDesc = tipoDesc;
    }
    public void setProduc(String produc){
        this.produc = produc;
    }
    public String getProduc(){
        return produc;
    }
    public void setDesc(String desc){
        this.desc = desc;
    }
    public String getDesc(){
        return desc;
    }
    public void setTipoDesc(Double tipoDesc){
        this.tipoDesc = tipoDesc;
    }
    public  Double  getTipoDesc(){
        return tipoDesc;
    }
}
