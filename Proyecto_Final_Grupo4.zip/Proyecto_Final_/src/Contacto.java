/**
 * Clase Contacto
 * <p>Objeto Base usado para crear la Tienda Virtual</p>
 * @author J.Barahona,E.Jimenez,J.Sanchez,R.Roldan
 *
 */
public class Contacto {

    /**
     * Atributo para almacenar el nombre
     */
    private String nombre;

    /**
     * Atributo para almacenar el numero
     */
    private int numero;

    /**
     * Atributo para almacenar el correo
     */
    private String correo;

    /**
     * Constructor de la clase Contacto, el cual recibe los valores por defecto
     */
    public Contacto(String nombre, int numero, String correo){
        this.nombre = nombre;
        this.numero = numero;
        this.correo = correo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }
}
