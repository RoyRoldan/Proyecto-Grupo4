/**
 * Clase ventas
 * <p>Objeto Base usado para crear la Tienda Virtual</p>
 * @author J.Barahona,E.Jimenez,J.Sanchez,R.Roldan
 *
 */
public class ventas {

    /**
     * Atributo para almacenar el ventasdiarias
     */
    private int ventasdiarias;

    /**
     * Atributo para almacenar el local
     */
    private String local;

    /**
     * Atributo para almacenar el dia
     */
    private String dia;

    /**
     * Atributo para almacenar el cierreCaja
     */
    private Double cierreCaja;

    /**
     * Constructor de la clase ventas, el cual recibe los valores por defecto
     */
    public ventas (String dia, String local, int ventasdiarias, Double cierreCaja){
        this.dia = dia;
        this.local = local;
        this.ventasdiarias = ventasdiarias;
        this.cierreCaja = cierreCaja;

    }

    public String getDia() {
        return dia;
    }

    public void setDia(String dia) {
        this.dia = dia;
    }

    public String getLocal() {
        return local;
    }

    public void setLocal(String local) {
        this.local = local;
    }

    public int getVentasdiarias() {
        return ventasdiarias;
    }

    public void setVentasdiarias(int ventasdiarias) {
        this.ventasdiarias = ventasdiarias;
    }

    public Double getCierreCaja() {
        return cierreCaja;
    }

    public void setCierreCaja(Double cierreCaja) {
        this.cierreCaja = cierreCaja;
    }
}