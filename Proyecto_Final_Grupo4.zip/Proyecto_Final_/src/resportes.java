/**
 * Clase resportes
 * <p>Objeto Base usado para crear la Tienda Virtual</p>
 * @author J.Barahona,E.Jimenez,J.Sanchez,R.Roldan
 *
 */
public class resportes {

    /**
     * Atributo para almacenar el nomCliente
     */
    private String nomCliente;

    /**
     * Atributo para almacenar el tienda
     */
    private String tienda;

    /**
     * Atributo para almacenar el producto
     */
    private String producto;

    /**
     * Atributo para almacenar el cantProduc
     */
    private int cantProduc;

    /**
     * Atributo para almacenar el preciofact
     */
    private Double preciofact;

    /**
     * Constructor de la clase resportes, el cual recibe los valores por defecto
     */
    public resportes(String nomCliente, String tienda, String producto, int cantProduc, Double preciofact){
        this.nomCliente = nomCliente;
        this.tienda = tienda;
        this.producto = producto;
        this.cantProduc = cantProduc;
        this.preciofact = preciofact;
    }

    public String getNomCliente() {
        return nomCliente;
    }

    public void setNomCliente(String nomCliente) {
        this.nomCliente = nomCliente;
    }

    public String getTienda() {
        return tienda;
    }

    public void setTienda(String tienda) {
        this.tienda = tienda;
    }

    public String getProducto() {
        return producto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }

    public int getCantProduc() {
        return cantProduc;
    }

    public void setCantProduc(int cantProduc) {
        this.cantProduc = cantProduc;
    }

    public Double getPreciofact() {
        return preciofact;
    }

    public void setPreciofact(Double preciofact) {
        this.preciofact = preciofact;
    }
}
